package com.example.platehunter

/**
 * Builds plates incrementally across speech segments.
 * - Letters, then digits; a new letter after digits (or after 3 letters) starts a NEW plate.
 * - Digits that arrive later (after a pause / another segment) are appended to the unfinished plate.
 * - A vehicle-type word (تاكسي، وانيت، نقل، ميكروباص، يامه) is attached to the current plate
 *   (if it has no type yet) or to the next plate.
 * - The word "لوحة" closes the current plate.
 * Every plate keeps the stamp (time + GPS) of the moment its first letter was heard.
 */
class PlateAssembler {
    class Stamp(val ms: Long, val lat: Double?, val lon: Double?)
    class Draft(var letters: String, var digits: String, var type: String?, val stamp: Stamp, var recordId: Long = -1L) {
        fun copyDraft() = Draft(letters, digits, type, stamp, recordId)
    }
    interface Sink { fun upsert(d: Draft, incomplete: Boolean) }

    var cur: Draft? = null
        private set
    private var pendingType: String? = null

    fun reset() { cur = null; pendingType = null }
    /** Makes an existing (edited) record the plate being built, so later speech continues it. */
    fun adopt(d: Draft) { cur = d; pendingType = null }
    fun dropRecord(id: Long) { if (cur?.recordId == id) cur = null }

    fun feed(text: String, stamp: Stamp, sink: Sink) {
        val r = run(text, cur, pendingType, stamp, sink); cur = r.first; pendingType = r.second
    }
    /** Preview only (no saving): returns the plate as it would look after this text. */
    fun peek(text: String, stamp: Stamp): Draft? = run(text, cur?.copyDraft(), pendingType, stamp, null).first
    /** Saves an unfinished plate (>=1 digit) without closing it, so later digits can still complete it. */
    fun flush(sink: Sink) {
        val c = cur ?: return
        if (c.letters.isNotEmpty()) sink.upsert(c, c.letters.length < 3 || c.digits.length < 3)
    }

    private val types = mapOf(
        "وانيت" to "وانيت", "ونيت" to "وانيت", "وانيط" to "وانيت", "وانت" to "وانيت",
        "تاكسي" to "تاكسي", "تكسي" to "تاكسي", "تاكسيي" to "تاكسي",
        "نقل" to "نقل", "نقال" to "نقل",
        "ميكروباص" to "ميكروباص", "ميكرو" to "ميكروباص", "ميكروباس" to "ميكروباص", "ميكربوص" to "ميكروباص",
        "يامه" to "يامه", "ياما" to "يامه", "يامها" to "يامه", "ياماها" to "يامه", "يمه" to "يامه"
    )
    private val stop = setOf("رقم", "نمره", "نمرة", "الرقم", "رقمها", "ورقم")

    private fun typeOf(w: String): String? = types[w.replace('ى', 'ي')]
    private fun digitsOf(w: String): String? =
        if (w.isNotEmpty() && w.all { it in '0'..'9' }) w else PlateParser.digitWord(w)

    private fun tokenize(text: String): List<String> {
        val s = PlateParser.normDigits(text)
            .replace(Regex("[\\u064B-\\u065F\\u0640]"), "")
            .replace(Regex("[،,؛;.!؟?:\\-_/\\\\]"), " ")
            .replace(Regex("(?<=[\\u0621-\\u064A])(?=[0-9])|(?<=[0-9])(?=[\\u0621-\\u064A])"), " ")
        return s.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.map { PlateParser.corrections[it] ?: it }
    }

    private fun letterTokens(w: String, next: String?): String? {
        PlateParser.letterOf(w)?.let { return it }
        if (w.length == 1 && w[0] in '\u0621'..'\u064A' && w != "و") return w
        if (w.length == 3 && w !in stop && w.all { it in '\u0621'..'\u064A' } && next != null && digitsOf(next) != null) return w
        return null
    }

    private fun run(text: String, startCur: Draft?, startPending: String?, stamp: Stamp, sink: Sink?): Pair<Draft?, String?> {
        var cur = startCur
        var pending = startPending
        fun touch() {
            val c = cur
            // Every heard letter/digit is saved right away (time of the first letter); incomplete until 3 letters + 3 digits.
            if (c != null && c.letters.isNotEmpty()) sink?.upsert(c, c.letters.length < 3 || c.digits.length < 3)
        }
        fun finish() {
            val c = cur
            if (c != null && c.letters.isNotEmpty()) sink?.upsert(c, c.letters.length < 3 || c.digits.length < 3)
            cur = null
        }
        val toks = tokenize(text)
        for ((i, w) in toks.withIndex()) {
            val type = typeOf(w)
            val dg = digitsOf(w)
            when {
                w == "لوحة" || w == "لوحه" || w == "اللوحة" || w == "اللوحه" -> finish()
                type != null -> {
                    val c = cur
                    if (c != null && c.type == null) { c.type = type; touch() } else pending = type
                }
                dg != null -> {
                    val c = cur
                    if (c != null && c.letters.isNotEmpty() && c.digits.length < 4) { c.digits = (c.digits + dg).take(4); touch() }
                }
                else -> {
                    val lt = letterTokens(w, toks.getOrNull(i + 1))
                    if (lt != null) {
                        var c = cur
                        if (c != null && (c.digits.isNotEmpty() || c.letters.length >= 3)) { finish(); c = null }
                        if (c == null) { c = Draft("", "", pending, stamp); pending = null; cur = c }
                        for (ch in lt) if (c.letters.length < 3) c.letters += ch
                        touch()
                    }
                }
            }
        }
        return Pair(cur, pending)
    }
}
