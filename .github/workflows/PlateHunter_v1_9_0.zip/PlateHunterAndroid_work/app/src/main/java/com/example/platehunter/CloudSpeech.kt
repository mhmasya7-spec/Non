package com.example.platehunter

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Deepgram live PCM streaming client. API keys should be proxied by a backend for public releases. */
class CloudSpeech(private val onText: (String, Boolean) -> Unit, private val onStatus: (String) -> Unit) {
    /** Boosts the Arabic letter names and vehicle types (Nova-3 keyterm prompting). */
    private fun keytermParams(): String =
        (PlateParser.letterNames + listOf("وانيت", "تاكسي", "نقل", "ميكروباص", "يامه", "لوحة"))
            .joinToString("") { "&keyterm=" + java.net.URLEncoder.encode(it, "UTF-8") }

    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    @Volatile private var running = false
    private var recorder: AudioRecord? = null
    private var socket: WebSocket? = null
    private var audioThread: Thread? = null

    fun start(apiKey: String) {
        if (apiKey.isBlank()) { onStatus("أدخل مفتاح Deepgram من الإعدادات"); return }
        if (running) return
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { onStatus("تسجيل الصوت غير مدعوم على هذا الجهاز"); return }
        val request = Request.Builder()
            .url("wss://api.deepgram.com/v1/listen?model=nova-3&language=ar&encoding=linear16&sample_rate=16000&channels=1&interim_results=true&smart_format=true&endpointing=300" + keytermParams())
            .header("Authorization", "Token $apiKey")
            .build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onStatus("متصل بـ Deepgram — الاستماع مباشر")
                startAudio(min)
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    val channel = root.optJSONObject("channel")
                    val transcript = channel?.optJSONArray("alternatives")?.optJSONObject(0)?.optString("transcript").orEmpty()
                    if (transcript.isNotBlank()) onText(transcript, root.optBoolean("speech_final", root.optBoolean("is_final", false)))
                } catch (_: Exception) { }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("تعذر اتصال Deepgram: ${t.message ?: "تحقق من المفتاح والإنترنت"}")
                stop()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onStatus("تم إغلاق اتصال Deepgram") }
        })
    }

    private fun startAudio(minBuffer: Int) {
        try {
            val bufferSize = maxOf(minBuffer, 4096)
            recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            val r = recorder ?: return
            if (r.state != AudioRecord.STATE_INITIALIZED) { onStatus("تعذر تهيئة الميكروفون"); stop(); return }
            r.startRecording(); running = true
            audioThread = Thread {
                val bytes = ByteArray(2048)
                while (running) {
                    val count = try { r.read(bytes, 0, bytes.size) } catch (_: Exception) { -1 }
                    if (count > 0) socket?.send(ByteString.of(*bytes.copyOf(count)))
                }
            }.apply { name = "PlateHunterAudioStream"; start() }
        } catch (e: Exception) { onStatus("خطأ في تشغيل الصوت: ${e.message}"); stop() }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
        socket?.send("""{"type":"CloseStream"}""")
        socket?.close(1000, "user stopped")
        socket = null
        audioThread = null
    }
}
